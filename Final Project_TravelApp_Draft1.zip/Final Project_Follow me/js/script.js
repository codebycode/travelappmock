$('document').ready(function(){

	L.mapbox.accessToken = 'pk.eyJ1IjoicGFtLSIsImEiOiJNT09NSzgwIn0.AWl1AY_kO1HMnFHwxb9mww';
	var map = L.mapbox.map('map', 'mapbox.streets')
    	.setView([40, -74.50], 9);
});
